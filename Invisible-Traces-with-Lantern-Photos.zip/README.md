# Invisible Traces

Website tĩnh dành cho GitHub Pages. Trang gồm ba mục chính: Ảnh nghệ thuật (7 làng nghề), Triển lãm và Tác động đến môi trường (5 chủ đề).

## Cập nhật nội dung

1. Mở `index.html`, tìm dòng `SỬA NỘI DUNG TẠI ĐÂY`.
2. Mục **Làm đèn lồng** đã có ba ảnh, bấm ảnh thu nhỏ để chuyển ảnh. Sửa 7 mục trong `villages`: `name`, `place`, `intro`, `note`. Tạo thư mục `images`, tải ảnh của bạn vào đó và đặt `image` thành `images/ten-anh.jpg`.
3. Sửa câu chuyện triển lãm trong thẻ `<section id="exhibition">`. Nếu có ảnh triển lãm, thay nội dung `.exhibit-art` bằng `<img src="images/trien-lam.jpg" alt="Không gian triển lãm">` và thêm CSS cho ảnh nếu cần.
4. Sửa 5 mục trong `topics` để đưa số liệu, ví dụ và nguồn đã kiểm chứng vào trang.

## Đưa lên GitHub Pages

Tạo repository mới trên GitHub, tải `index.html`, `README.md` và thư mục `images` (nếu có) lên **thư mục gốc**. Vào **Settings → Pages → Build and deployment**, chọn **Deploy from a branch**, chọn **main** và **/(root)** rồi lưu. Trang sẽ có dạng `https://TEN-TAI-KHOAN.github.io/TEN-REPOSITORY/`.

Trang không cần cài đặt hay build. Mở `index.html` trên máy để xem trước.
